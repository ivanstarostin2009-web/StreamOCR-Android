package ru.streamocr

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    companion object {
        const val ACTION_START = "ru.streamocr.START"
        const val ACTION_RESULT = "ru.streamocr.RESULT"
        const val ACTION_STATUS = "ru.streamocr.STATUS"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        private const val CHANNEL = "streamocr_capture"
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var job: Job? = null
    private var ocr: OcrEngine? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val running = AtomicBoolean(false)
    private val sent = mutableSetOf<String>()
    private var lastRecognized: String? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    10,
                    notification("Запрос доступа к экрану"),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(10, notification("Запрос доступа к экрану"))
            }
            val code = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            val data = if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
            else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
            if (data != null) startCapture(code, data)
        }
        return START_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        if (running.getAndSet(true)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                running.set(false)
                stopSelf()
            }
        }, null)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay(
            "StreamOCR", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, null
        )

        ocr = OcrEngine(this)
        job = scope.launch {
            val ready = withContext(Dispatchers.IO) { ocr?.initialize() == true }
            if (!ready) {
                status("Не удалось загрузить OCR-модели. Проверь интернет и перезапусти мониторинг.")
                stopSelf()
                return@launch
            }
            status("Мониторинг запущен")
            while (isActive && running.get()) {
                val started = System.currentTimeMillis()
                val prefs = getSharedPreferences("streamocr", MODE_PRIVATE)
                val left = prefs.getInt("left", 0)
                val top = prefs.getInt("top", 0)
                val w = prefs.getInt("width", width)
                val h = prefs.getInt("height", height)
                val bitmap = withContext(Dispatchers.IO) { captureCrop(left, top, w, h) }
                if (bitmap != null) {
                    val code = withContext(Dispatchers.Default) { ocr?.recognize(bitmap) }
                    bitmap.recycle()
                    if (code != null && code != lastRecognized) {
                        lastRecognized = code
                        sendBroadcast(Intent(ACTION_RESULT).setPackage(packageName).putExtra("code", code))
                        if (prefs.getBoolean("auto_send", false) && sent.add(code)) {
                            sendBroadcast(Intent(TelegramAccessibilityService.ACTION_SEND_CODE)
                                .setPackage(packageName).putExtra("code", code))
                        }
                    }
                }
                val interval = prefs.getInt("interval", 700).coerceIn(250, 10000)
                delay((interval - (System.currentTimeMillis() - started)).coerceAtLeast(30))
            }
        }
    }

    private fun captureCrop(left: Int, top: Int, width: Int, height: Int): Bitmap? {
        val image = reader?.acquireLatestImage() ?: return null
        try {
            val plane = image.planes[0]
            val buffer: ByteBuffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val full = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
            )
            full.copyPixelsFromBuffer(buffer)
            val x = left.coerceIn(0, full.width - 1)
            val y = top.coerceIn(0, full.height - 1)
            val w = width.coerceAtLeast(1).coerceAtMost(full.width - x)
            val h = height.coerceAtLeast(1).coerceAtMost(full.height - y)
            val crop = Bitmap.createBitmap(full, x, y, w, h)
            full.recycle()
            return crop
        } catch (_: Exception) {
            return null
        } finally {
            image.close()
        }
    }

    private fun status(text: String) {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra("message", text))
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(10, notification(text))
    }

    private fun notification(text: String): android.app.Notification {
        val immutableFlag = if (Build.VERSION.SDK_INT >= 23)
            android.app.PendingIntent.FLAG_IMMUTABLE else 0
        val openApp = android.app.PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("StreamOCR")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "StreamOCR мониторинг", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        running.set(false)
        job?.cancel()
        virtualDisplay?.release()
        reader?.close()
        projection?.stop()
        ocr?.close()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
