package ru.streamocr

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class TelegramAccessibilityService : AccessibilityService() {
    companion object { const val ACTION_SEND_CODE = "ru.streamocr.SEND_CODE" }
    private var receiver: BroadcastReceiver? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val code = intent?.getStringExtra("code") ?: return
                typeIntoCurrentTelegramChat(code)
            }
        }
        val filter = IntentFilter(ACTION_SEND_CODE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(receiver, filter)
    }

    private fun typeIntoCurrentTelegramChat(code: String) {
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString().orEmpty()
        if (pkg != "org.telegram.messenger" && pkg != "org.telegram.messenger.web") return

        val editable = mutableListOf<AccessibilityNodeInfo>()
        collectEditable(root, editable)
        val field = editable.lastOrNull { it.isVisibleToUser && it.isEnabled }
            ?: return
        field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = android.os.Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, code)
        }
        if (field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            field.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            field.performAction(AccessibilityNodeInfo.ACTION_IME_ENTER)
        }
    }

    private fun collectEditable(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        if (node.isEditable) out.add(node)
        for (i in 0 until node.childCount) node.getChild(i)?.let { collectEditable(it, out) }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        receiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        receiver = null
        super.onDestroy()
    }
}
