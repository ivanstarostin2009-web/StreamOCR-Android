package ru.streamocr

import android.content.Context
import android.graphics.Bitmap
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

class OcrEngine(private val context: Context) {
    private var api: TessBaseAPI? = null
    private val downloading = AtomicBoolean(false)

    fun initialize(): Boolean {
        val tessDir = File(context.filesDir, "tesseract")
        val dataDir = File(tessDir, "tessdata")
        if (!dataDir.exists()) dataDir.mkdirs()
        val rus = File(dataDir, "rus.traineddata")
        val eng = File(dataDir, "eng.traineddata")
        try {
            if (!rus.exists() || !eng.exists()) {
                if (!downloading.compareAndSet(false, true)) return false
                downloadModel("rus", rus)
                downloadModel("eng", eng)
                downloading.set(false)
            }
            val instance = TessBaseAPI()
            if (!instance.init(tessDir.absolutePath, "rus+eng")) return false
            api = instance
            return true
        } catch (_: Exception) {
            downloading.set(false)
            return false
        }
    }

    private fun downloadModel(lang: String, destination: File) {
        val url = URL("https://github.com/tesseract-ocr/tessdata_fast/raw/main/$lang.traineddata")
        url.openConnection().apply {
            connectTimeout = 15000
            readTimeout = 30000
        }.getInputStream().use { input ->
            destination.outputStream().use { output -> input.copyTo(output) }
        }
    }

    @Synchronized
    fun recognize(bitmap: Bitmap): String? {
        val engine = api ?: return null
        val scaled = Bitmap.createScaledBitmap(
            bitmap, bitmap.width * 3, bitmap.height * 3, true
        )
        return try {
            // Сбрасываем цифровую маску от предыдущего резервного прохода,
            // чтобы на следующем кадре снова читалось слово «Код».
            engine.setVariable(
                TessBaseAPI.VAR_CHAR_WHITELIST,
                "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя"
            )
            engine.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
            engine.setImage(scaled)
            val text = engine.utF8Text ?: ""
            val codeRegex = Regex("(?is)код.{0,35}?((?:\\d[\\s.,:_-]*){4}\\d)")
            val contextual = codeRegex.find(text)?.groupValues?.getOrNull(1)
                ?.filter(Char::isDigit)
            if (contextual?.length == 5) return contextual

            engine.setVariable(TessBaseAPI.VAR_CHAR_WHITELIST, "0123456789")
            engine.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_LINE)
            engine.setImage(scaled)
            val digits = engine.utF8Text.orEmpty()
            val matches = Regex("(?<!\\d)(\\d{5})(?!\\d)").findAll(digits).map { it.value }.distinct().toList()
            matches.singleOrNull()
        } finally {
            scaled.recycle()
            engine.clear()
        }
    }

    fun close() { api?.end(); api = null }
}
