package ru.streamocr

import android.app.Activity
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.content.Context
import android.widget.Toast

class SelectAreaActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Toast.makeText(this, "Проведи пальцем по плашке «Код: 12345»", Toast.LENGTH_LONG).show()
        window.setBackgroundDrawableResource(android.R.color.transparent)
        setContentView(SelectionView(this) { l, t, r, b ->
            getSharedPreferences("streamocr", MODE_PRIVATE).edit()
                .putInt("left", l).putInt("top", t)
                .putInt("width", r - l).putInt("height", b - t).apply()
            Toast.makeText(this, "Область сохранена", Toast.LENGTH_SHORT).show()
            finish()
        })
    }

    private class SelectionView(context: Context, val done: (Int, Int, Int, Int) -> Unit) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.GREEN
            style = Paint.Style.STROKE
            strokeWidth = 5f
        }
        private var sx = 0f
        private var sy = 0f
        private var ex = 0f
        private var ey = 0f
        private var drawing = false

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (drawing) canvas.drawRect(sx, sy, ex, ey, paint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = event.rawX; sy = event.rawY
                    ex = sx; ey = sy; drawing = true; invalidate()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    ex = event.rawX; ey = event.rawY; invalidate()
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    ex = event.rawX; ey = event.rawY
                    val l = minOf(sx, ex).toInt().coerceAtLeast(0)
                    val t = minOf(sy, ey).toInt().coerceAtLeast(0)
                    val r = maxOf(sx, ex).toInt()
                    val b = maxOf(sy, ey).toInt()
                    if (r - l > 20 && b - t > 20) done(l, t, r, b) else finish()
                    return true
                }
            }
            return true
        }
    }
}
