package ru.streamocr

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.graphics.Typeface

class OverlayService : Service() {
    companion object {
        const val ACTION_SELECT = "ru.streamocr.OVERLAY_SELECT"
        const val ACTION_SHOW = "ru.streamocr.OVERLAY_SHOW"
        const val ACTION_HIDE = "ru.streamocr.OVERLAY_HIDE"
    }

    private lateinit var wm: WindowManager
    private var selectionView: View? = null
    private var resultView: TextView? = null
    private var receiver: BroadcastReceiver? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == CaptureService.ACTION_RESULT) {
                    val code = intent.getStringExtra("code") ?: return
                    showResult(code)
                }
            }
        }
        val filter = IntentFilter(CaptureService.ACTION_RESULT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(receiver, filter)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SELECT -> showSelector()
            ACTION_SHOW -> showResult("Ожидание...")
            ACTION_HIDE -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun showSelector() {
        removeSelection()
        val view = object : View(this) {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.GREEN
                style = Paint.Style.STROKE
                strokeWidth = 5f
            }
            var sx = 0f; var sy = 0f; var ex = 0f; var ey = 0f
            var drawing = false

            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                canvas.drawColor(0x22000000)
                if (drawing) canvas.drawRect(sx, sy, ex, ey, paint)
            }

            override fun onTouchEvent(event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = event.x; sy = event.y; ex = sx; ey = sy
                        drawing = true; invalidate(); return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        ex = event.x; ey = event.y; invalidate(); return true
                    }
                    MotionEvent.ACTION_UP -> {
                        ex = event.x; ey = event.y
                        val left = minOf(sx, ex).toInt().coerceAtLeast(0)
                        val top = minOf(sy, ey).toInt().coerceAtLeast(0)
                        val right = maxOf(sx, ex).toInt()
                        val bottom = maxOf(sy, ey).toInt()
                        if (right - left > 20 && bottom - top > 20) {
                            getSharedPreferences("streamocr", MODE_PRIVATE).edit()
                                .putInt("left", left).putInt("top", top)
                                .putInt("width", right - left).putInt("height", bottom - top).apply()
                        }
                        removeSelection()
                        showResult("Ожидание...")
                        return true
                    }
                }
                return true
            }
        }
        selectionView = view
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(view, params)
    }

    private fun removeSelection() {
        selectionView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        selectionView = null
    }

    private fun showResult(text: String) {
        if (resultView == null) {
            resultView = TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = 24f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(22, 12, 22, 12)
                setBackgroundColor(0xDD202020.toInt())
                setOnClickListener { showSelector() }
            }
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 18; y = 100
            }
            wm.addView(resultView, params)
        }
        resultView?.text = text
    }

    override fun onDestroy() {
        removeSelection()
        resultView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        resultView = null
        receiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        receiver = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
