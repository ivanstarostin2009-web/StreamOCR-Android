package ru.streamocr

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("streamocr", MODE_PRIVATE) }
    private val captureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                action = CaptureService.ACTION_START
                putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(CaptureService.EXTRA_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, service)
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, OverlayService::class.java).apply {
                    action = OverlayService.ACTION_SHOW
                })
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 2001)
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var interval by remember { mutableStateOf(prefs.getInt("interval", 700).toString()) }
                var autoSend by remember { mutableStateOf(prefs.getBoolean("auto_send", false)) }
                var running by remember { mutableStateOf(false) }
                var last by remember { mutableStateOf(prefs.getString("last", "Ожидание...") ?: "Ожидание...") }
                var history by remember { mutableStateOf(loadHistory()) }
                var message by remember { mutableStateOf("Готов к работе") }

                DisposableEffect(Unit) {
                    val receiver = object : android.content.BroadcastReceiver() {
                        override fun onReceive(context: android.content.Context?, intent: Intent?) {
                            when (intent?.action) {
                                CaptureService.ACTION_RESULT -> {
                                    val code = intent.getStringExtra("code") ?: return
                                    last = code
                                    history = (listOf(code) + history).distinct().take(20)
                                    prefs.edit().putString("last", code)
                                        .putString("history", history.joinToString(",")).apply()
                                    message = "Новое число распознано"
                                }
                                CaptureService.ACTION_STATUS -> {
                                    message = intent.getStringExtra("message") ?: message
                                }
                            }
                        }
                    }
                    val filter = android.content.IntentFilter().apply {
                        addAction(CaptureService.ACTION_RESULT)
                        addAction(CaptureService.ACTION_STATUS)
                    }
                    if (android.os.Build.VERSION.SDK_INT >= 33) {
                        registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
                    } else {
                        @Suppress("DEPRECATION")
                        registerReceiver(receiver, filter)
                    }
                    onDispose { unregisterReceiver(receiver) }
                }

                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("StreamOCR", style = MaterialTheme.typography.headlineLarge)
                        Text(message, color = MaterialTheme.colorScheme.secondary)
                        Text("Последнее распознанное число", style = MaterialTheme.typography.titleMedium)
                        Text(last, style = MaterialTheme.typography.displayMedium)
                        OutlinedTextField(
                            value = interval, onValueChange = { interval = it.filter(Char::isDigit).take(5) },
                            label = { Text("Интервал проверки (мс)") }, singleLine = true
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                val value = (interval.toIntOrNull() ?: 700).coerceIn(250, 10000)
                                interval = value.toString()
                                prefs.edit().putInt("interval", value).apply()
                                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                                captureLauncher.launch(manager.createScreenCaptureIntent())
                            }, enabled = !running) { Text("Начать мониторинг") }
                            OutlinedButton(onClick = {
                                stopService(Intent(this@MainActivity, CaptureService::class.java))
                                running = false
                                message = "Мониторинг остановлен"
                            }) { Text("Остановить") }
                        }
                        OutlinedButton(onClick = {
                            if (!Settings.canDrawOverlays(this@MainActivity)) {
                                startActivity(Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:$packageName")
                                ))
                            } else {
                                startService(Intent(this@MainActivity, OverlayService::class.java).apply {
                                    action = OverlayService.ACTION_SELECT
                                })
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Выбрать область экрана") }
                        Row {
                            Column(Modifier.weight(1f)) {
                                Text("Автоотправка в текущий чат Telegram")
                                Text("По умолчанию выключена", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = autoSend, onCheckedChange = {
                                autoSend = it
                                prefs.edit().putBoolean("auto_send", it).apply()
                                if (it) {
                                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                                }
                            })
                        }
                        OutlinedButton(onClick = {
                            prefs.edit().remove("history").remove("last").apply()
                            history = emptyList()
                            last = "Ожидание..."
                        }, modifier = Modifier.fillMaxWidth()) { Text("Очистить историю") }
                        Text("История распознавания", style = MaterialTheme.typography.titleLarge)
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(history) { code -> Text(code, style = MaterialTheme.typography.bodyLarge) }
                        }
                        Text(
                            "Для работы разреши захват экрана. Для автоотправки отдельно включи службу StreamOCR в настройках специальных возможностей.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }

    private fun loadHistory(): List<String> =
        prefs.getString("history", "")?.split(",")?.filter { it.matches(Regex("\\d{5}")) } ?: emptyList()
}
